﻿using RoleBase_Project_Mvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Web.Security;

namespace RoleBase_Project_Mvc.Controllers
{
    public class RegisterController : Controller
    {
        public object FormAuthentication { get; private set; }

        // GET: Register
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Signup()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Signup(tbl_user model)
        {
            using (var context=new pk_dbEntities())
            {
                context.tbl_user.Add(model);
                context.SaveChanges();
            }
            return RedirectToAction("Login");
        }
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Models.Membership model)
        {
            using (var context = new pk_dbEntities())
            {
                 bool isValid = context.tbl_user.Any(x => x.Username == model.Username && x.Password == model.Password);
                if(isValid)
                {
                    FormsAuthentication.SetAuthCookie(model.Username, false);
                    return RedirectToAction("Index","tbl_student");
                }
                ModelState.AddModelError("","Invalid username or password");
                return View();
            }

            
        }
        public ActionResult DashBoard()
        {
            return View();
        }

        
        public ActionResult logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }
    }
}